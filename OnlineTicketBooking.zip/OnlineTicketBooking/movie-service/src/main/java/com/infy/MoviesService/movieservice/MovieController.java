package com.infy.MoviesService.movieservice;


import java.util.List;
import javax.validation.Valid;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;




@RestController
public class MovieController {
    
    @Autowired
    private MovieService service;
    
    //get-all-movies
    @GetMapping(value ="/AllMovies")
    public ResponseEntity<List<Movie>> getMovies(){
        return new ResponseEntity<>(service.getMovies(),HttpStatus.OK);
    }
    
    //get-movie-by-id
    @GetMapping(value ="/movie/{id}")
    public ResponseEntity<Movie> getMovieByMovieId(@PathVariable("id") Integer id){
        return new ResponseEntity<>(service.getMovieByMovieId(id),HttpStatus.OK);
    }
    
    //get-movie-by-movie-name
    @GetMapping(value ="/movie/name/{movieName}")
    public ResponseEntity<List<Movie>> getMovieByMovieName(@PathVariable("movieName") String movieName){
        return new ResponseEntity<>(service.getMoviesBymovieName(movieName),HttpStatus.OK);
    }
    
    //add-movie
    @PostMapping(value ="/addmovie")
    public ResponseEntity<Movie> addMovie(@Valid @RequestBody Movie movie){
        return new ResponseEntity<>(service.addMovie(movie),HttpStatus.OK);
    }
    
    //update-movie
    @RequestMapping(method=RequestMethod.PUT, value="/updatemovie/{id}")
    public ResponseEntity<Movie> updateMovieDetails(@PathVariable("id") Integer id,@Valid @RequestBody Movie movie){
        return new ResponseEntity<>(service.updateDetails(id,movie), HttpStatus.OK);
       
    }
    
    //delete-movie
    @DeleteMapping(path = "/movie/{id}")
    public ResponseEntity <Void> deleteMovie(@PathVariable("id") Integer id){
    service.deleteByMovieId(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }

}