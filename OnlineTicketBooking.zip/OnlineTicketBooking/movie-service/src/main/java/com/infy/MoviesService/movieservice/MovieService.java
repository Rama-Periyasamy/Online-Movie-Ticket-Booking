package com.infy.MoviesService.movieservice;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service
public class MovieService {

	@Autowired
	private MovieRepository repo;


	public List<Movie> getMovies() {
		return (List<Movie>) repo.findAll();
	}
	
	public Movie getMovieByMovieId(Integer id) {
		return repo.findById(id).get();
	}
	
	public List<Movie> getMoviesBymovieName(String movieName) {
		return (List<Movie>) repo.findBymovieName(movieName);
	}
	
	
	public Movie addMovie(Movie movie) {
		return repo.save(movie);
	}
	
	public Movie updateDetails(Integer id,Movie movie) {
		movie.setMovieId(id);
		return repo.save(movie);
	}
	
	public void deleteByMovieId(Integer id) {
		repo.deleteById(id);
	}

}